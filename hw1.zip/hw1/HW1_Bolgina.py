import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, KFold, cross_val_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import classification_report, f1_score
from sklearn import grid_search
from sklearn import tree
import pydotplus
#Задание 1.

df  = pd.read_csv('titanic.csv', index_col = "PassengerId")
#sns.barplot(x="Sex", y="Survived", data = df);
#plt.show()#Вероятность выжить у мужчин составила 19% и оказалась ниже, чем у женщин - 74%
#sns.barplot(x="Pclass", y="Survived", data = df);
#plt.show()#Самая высокая вероятность выжить у пассажиров класса 1(63%), затем класса 2(47%) и класса 3 (24%)
#sns.boxplot(x="Pclass", y="Fare", data = df);
#plt.show()#стоимость билетов в среднем больше у пассажиров 1-го класса(61), у 2 класса ниже (в среднем 20), 3 класс - 14. Только среди пассажиров первого класса есть большие выбросы - 514, 262

#Задание 2.

#sns.factorplot(x="Pclass", y="Survived", hue="Sex", data=df, kind="bar");
#plt.show()# Ответ: P(FS|C1)= 96%, P(FS|C3)>P(MS|C1)(50%>39%), F - женщина, S - выживший, С - класс

#Задание 3 (чистка данных)

df['Age'] = df['Age'].fillna(df['Age'].mean())
df['Sex'] = df['Sex'].map({'female': 0, 'male':1}).astype(int)
x_labels = ['Pclass', 'Fare', 'Age', 'Sex', 'SibSp']
X, y = df[x_labels], df['Survived']
#print(X.describe())

# Задание 4.

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3)
#print(X_train.shape, X_test.shape, y_train.shape, y_test.shape)
#print(X_train.describe())
scores = []
# for i in range(1,100): # На мой взгляд, целесообразно менять 3 параметра - глубину дерева, количество листьев и split. Варьирую параметр количества листьев в моем дереве, от 1 до 100. Судя по выдаче, максимальные полнота, точность, f-мера при количестве листьев 3
#     clf = DecisionTreeClassifier( min_samples_leaf=i)
#     clf.fit(np.array(X_train), np.array(y_train))
#     y_pred = clf.predict(X_test)
#     scores.append(f1_score(y_test, y_pred))
    #print('leafs', i, classification_report(y_test, y_pred))

# plt.plot(scores) # строю диаграмму, чтобы посмотреть при каком значении параметра были самые лучшие результаты
# plt.xlabel('min_samples_leaf')
# plt.ylabel('f1-score')
# plt.show()# диаграмму прикрепляю отдельным файлом, получается, что самые лучшие оценки для min_samples_leaf = 4, то есть когда у дерева 4 листа, классификатор работает лучше всего - с точностью 0,74
# clf = DecisionTreeClassifier( min_samples_leaf=4)
# clf.fit(np.array(X_train), np.array(y_train))
# dot_data = tree.export_graphviz(clf, out_file=None)
# graph = pydotplus.graph_from_dot_data(dot_data)
# print(graph)
# graph.write_pdf("C:/Users/user/Documents/4 курс/программирование 4-й курс/Mashing learning/hw1/tree.pdf")

# Задание Extra (GridSearch):

# parameters = {'min_samples_leaf': (1, 2, 3, 4, 5, 6), 'max_depth': (10, 20, 30, 40, 50, 60), 'min_samples_split': (2, 3, 4, 5, 6, 7)}
# gs = grid_search.GridSearchCV(DecisionTreeClassifier(), parameters)
# gs.fit(X_train, y_train)
# print('Best result is ',gs.best_score_)
# print('Best min_samples_leaf is', gs.best_estimator_.min_samples_leaf)
# print('Best max_depth is', gs.best_estimator_.max_depth)
# print('Best min_samples_split', gs.best_estimator_.min_samples_split)# GridSearch говорит, что лучший критерий min_samples_leaf = 1, max_depth = 40, min_samples_split = 5, при этом точность = 0,8

#Задание Super–duper-Extra(ROC - кривая)


# Задание 5. Все то же самое для классификатора RandomForest

# scores = []
# for i in range(1,100):
#     model = RandomForestClassifier(n_estimators=i)
#     model.fit(X_train, y_train)
#     y_pred = model.predict(X_test)
#     scores.append(f1_score(y_test, y_pred))
#
# plt.plot(scores)
# plt.xlabel('n_estimators')
# plt.ylabel('score')
# plt.show()# согдасно графику(отдельным файлом), лучше всего работает классификатор при 41 деревьях(n_estimators=41). При этом, рэндом форест лучше, чем дерево решений, так как точность улучшилась с 0,74 до 0,77

# parameters = {'n_estimators': (40, 20, 50, 60, 10, 35), 'max_depth': (10, 20, 30, 40, 50, 60), 'min_samples_split': (2, 3, 4, 5, 6, 7)}
# gs = grid_search.GridSearchCV(RandomForestClassifier(), parameters)
# gs.fit(X_train, y_train)
# print('Best result is ',gs.best_score_)
# print('Best n_estimators is', gs.best_estimator_.n_estimators)
# print('Best max_depth is', gs.best_estimator_.max_depth)
# print('Best min_samples_split', gs.best_estimator_.min_samples_split)# GridSearch говорит, что лучшие критерии n_estimators = 60, max_depth = 20, min_samples_split = 7, при этом точность стала выше = 0,82
